# Calibration analysis: 20261027T213729-54efcdb3

## Coverage and quality

- Complete: True; counts match: True.
- 5,970 frames over 198.98s at 30.00 FPS.
- Labels (frames): {'unlabeled': 2103, 'valid': 1873, 'invalid': 1994}.
- Estimated label seconds: {'invalid': 66.5369426, 'unlabeled': 70.0893915, 'valid': 62.390634899999995}.
- Holds: {'unlabeled': 14, 'valid': 7, 'invalid': 6}.
- Usable base measurements: 5970/5970 frames.
- Feature null mismatches: 0; maximum recompute error: 0.

## Feature comparison (1s trimmed from each labeled hold boundary)

| Feature | Valid median | Invalid median | Blocked balanced accuracy (raw / deviation) |
|---|---:|---:|---:|
| shoulder_angle_deg | -0.9943 | -1.3471 | 59.5% / 53.4% |
| head_offset_x | 0.0853 | 0.0993 | 63.5% / 61.7% |
| head_offset_y | 0.6875 | 0.5629 | 100.0% / 100.0% |
| mouth_shoulder_vertical | 0.4722 | 0.3321 | 100.0% / 100.0% |
| eye_ear_vertical | 0.0490 | 0.0195 | 100.0% / 100.0% |
| shoulder_width | 0.3511 | 0.3786 | 62.8% / 67.3% |
| facial_asymmetry | -0.2109 | -0.1501 | 73.4% / 64.3% |

Balanced accuracy averages valid and invalid recall. Complete holds are excluded from training one at a time. Threshold direction and deviation centre are fitted on training data only. These are within-session exploratory estimates, not performance on unseen users/days. Adjacent frames are correlated, and ranking multiple features adds selection optimism.

## Boundary sensitivity (raw-threshold blocked balanced accuracy)

| Trim seconds per end | Retained frames | Head height | Mouth height | Eye-ear height |
|---:|---:|---:|---:|---:|
| 0.0 | 3867 | 100.0% | 100.0% | 100.0% |
| 1.0 | 3072 | 100.0% | 100.0% | 100.0% |
| 2.0 | 2298 | 100.0% | 100.0% | 100.0% |
| 3.0 | 1575 | 100.0% | 100.0% | 100.0% |

Different trim settings evaluate different subsets; higher scores do not demonstrate an improved model.

## Frozen earlier thresholds on this recording

| Feature | Earlier threshold (invalid below) | Balanced accuracy | Invalid recall | Valid recall |
|---|---:|---:|---:|---:|
| head_offset_y | 0.61576 | 100.0% | 100.0% | 100.0% |
| mouth_shoulder_vertical | 0.40696 | 100.0% | 100.0% | 100.0% |
| eye_ear_vertical | 0.02591 | 89.3% | 78.5% | 100.0% |

The earlier thresholds are frozen constants from the preceding analysis; the older raw data is not currently available for reanalysis. New-session threshold fits are not substitutes for these transfer results.

## Timing and interpretation

Matching head-height crossings inside explicit transition gaps: 12/12 label changes. This diagnostic uses a smoothed feature and a threshold fitted to the recording; it is not independent ground truth. See statistics.json for exact crossings, intervals, and all fold results.

## Artifacts and reproduction

- feature_timeline.png: raw features and all manual labels.
- feature_distributions.png: class distributions and individual hold medians.
- feature_correlation.png: feature redundancy.
- statistics.json: complete calculations and validation folds.

Every analysis step is in src/analysis/calibration_analysis.py, a percent-format Python notebook. Run it cell by cell or execute `uv run python src/analysis/calibration_analysis.py`. Raw samples are read-only. Edit SESSION_ID to inspect a different recording.


## Conclusions and next steps

- **head_offset_y**: 100.0% whole-hold-out balanced accuracy on this recording's labeled interiors. Earlier frozen threshold: 100.0% balanced accuracy, 100.0% invalid recall.
- **mouth_shoulder_vertical**: 100.0% whole-hold-out balanced accuracy on this recording's labeled interiors. Earlier frozen threshold: 100.0% balanced accuracy, 100.0% invalid recall.
- **eye_ear_vertical**: 100.0% whole-hold-out balanced accuracy on this recording's labeled interiors. Earlier frozen threshold: 89.3% balanced accuracy, 78.5% invalid recall.
- Head height and mouth height correlate at r=0.9976. They largely repeat the same signal here. Start with one primary feature; test whether the others add value on new movement types before combining votes.
- The transition diagnostic finds a matching head-height crossing inside 12/12 explicit unlabeled transition gaps. The untrimmed and trimmed results are in the sensitivity table; agreement across trim widths supports cleaner labels but is not independent proof that every label is correct.
- Shoulder angle, horizontal head position, width, and facial asymmetry are secondary signals for this recording. Inspect their per-hold folds before deciding to use them. Near-perfect vertical separation does not establish their usefulness for lateral lean or head tilt.
- Motion should primarily support stability/settling assessment. A held invalid posture can have zero velocity. The JSON includes every rolling-variation and signed-velocity score.
- Median head-to-shoulder pixel separation: 156.3 valid vs 136.2 invalid. Median shoulder width: 224.7px vs 242.3px. Both numerator and denominator contribute to the normalized feature difference. Retain apparent width as a setup/scale diagnostic.
- For the next evaluation, keep unlabeled transitions and add different invalid subtypes, valid head turns, small posture deviations, and ordinary desk activity. Record new days and camera placements, then hold out complete sessions for final testing.
- Use a personal stable reference rather than promoting these fitted cutoffs to global rules. Tune persistence/hysteresis on separate recordings. Perfect separation of this sample does not establish warning delay or false-alarm rates during normal work.
